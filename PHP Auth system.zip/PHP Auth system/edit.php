<?php
    include 'config.php'; 

    
    if(!isset($_COOKIE['email'])) {
        header("Location: login.php");
        exit(); 
    }

    
    $email = $_COOKIE['email'];

    // Fetch user details from database
    $sql = "SELECT * FROM php.USER WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $NAME = $user['fname'];
        $PASS = $user['password'];
        
    } else {
        echo "User not found";
        exit();
    }

    
    $name = $email = $password = $cpassword = "";
    $nameErr = $emailErr = $passwordErr = $cpasswordErr = "";
    $isValid = true;

    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = test_input($_POST["fname"]);
        $email = test_input($_POST["email"]);
        $password = test_input($_POST["password"]);
        $cpassword = test_input($_POST["cpassword"]);

       

      
        $sql = "UPDATE php.USER SET fname=?, email=?, password=?, cpassword=? WHERE email=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $name, $email, $password, $cpassword, $email); 

        if ($stmt->execute()) {
            echo '<script>alert("Data updated successfully");</script>';
            
        } else {
            echo "Error: " . $stmt->error;
            echo '<script>alert("Data Not updated ");</script>';
        }
    }

    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <span class="navbar-text">
                    Welcome, <?php echo htmlspecialchars($email); ?>
                </span>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2>Edit Profile</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="fname" placeholder="Enter your name" value="<?php echo isset($NAME) ? htmlspecialchars($NAME) : ''; ?>">
            <!-- Validation error message -->
        </div>
        <div class="form-group">
            <label for="email">Email address</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" >
            <!-- Email cannot be edited -->
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
            <!-- Validation error message -->
        </div>
        <div class="form-group">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" class="form-control" id="confirmPassword" name="cpassword" placeholder="Confirm your password">
            <!-- Validation error message -->
        </div>
        <button type="submit" class="btn btn-primary">Edit</button>
    </form>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
