<?php
session_start(); 

if (!isset($_COOKIE['email'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from cookies
$email = isset($_COOKIE['email']) ? $_COOKIE['email'] : '';
$fname = isset($_COOKIE['fname']) ? $_COOKIE['fname'] : '';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome to Home Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a light blue background color and some padding to the footer */
        footer {
            background-color: lightblue;
            padding: 25px;
        }
    </style>
</head>

<body>

    <!-- Navigation bar -->
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Portfolio</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="#">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="#">Gallery</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="edit.php"><span class="glyphicon glyphicon-edit"></span> <?php echo htmlspecialchars($email); ?></a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main content -->
    <div class="jumbotron">
        <div class="container text-center">
            <h1>Welcome, <?php echo htmlspecialchars($fname); ?></h1>
            <h2>Portfolio</h2>
        </div>
    </div>

    <!-- Portfolio projects -->
    <div class="container-fluid bg-3 text-center">
        <div class="row">
            <div class="col-sm-3">
                <h3>Project 1</h3>
                <p>Some text..</p>
                <img src="https://placehold.it/150x80?text=PROJECT1" class="img-responsive" style="width:100%"
                    alt="Project 1 Image">
            </div>
            <div class="col-sm-3">
                <h3>Project 2</h3>
                <p>Some text..</p>
                <img src="https://placehold.it/150x80?text=PROJECT2" class="img-responsive" style="width:100%"
                    alt="Project 2 Image">
            </div>
            <div class="col-sm-3">
                <h3>Project 3</h3>
                <p>Some text..</p>
                <img src="https://placehold.it/150x80?text=PROJECT3" class="img-responsive" style="width:100%"
                    alt="Project 3 Image">
            </div>
            <div class="col-sm-3">
                <h3>Project 4</h3>
                <p>Some text..</p>
                <img src="https://placehold.it/150x80?text=PROJECT4" class="img-responsive" style="width:100%"
                    alt="Project 4 Image">
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="container-fluid text-center">
        <p>Footer Text</p>
    </footer>

</body>

</html>
