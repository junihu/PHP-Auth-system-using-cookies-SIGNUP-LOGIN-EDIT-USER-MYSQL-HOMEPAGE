<?php

include 'config.php';


$sql = "CREATE TABLE IF NOT EXISTS php.USER (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(30) NOT NULL,
    email VARCHAR(30) NOT NULL,
    password VARCHAR(50),
    cpassword VARCHAR(50)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}


$name = $email = $password = $cpassword = "";
$nameErr = $emailErr = $passwordErr = $cpasswordErr = "";
$isValid = true; 


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    if (empty($_POST['fname'])) {
        $nameErr = "Name is required";
        $isValid = false;
    } else {
        $name = test_input($_POST["fname"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
            $isValid = false;
        }
    }

    if (empty($_POST['email'])) {
        $emailErr = "Email is Required";
        $isValid = false;
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $isValid = false;
        }
    }

    if (empty($_POST['password'])) {
        $passwordErr = "Password is required";
        $isValid = false;
    } else {
        $password = test_input($_POST["password"]);
    }

    if (empty($_POST['cpassword'])) {
        $cpasswordErr = "Confirm password is required";
        $isValid = false;
    } else {
        $cpassword = test_input($_POST["cpassword"]);
        if ($password != $cpassword) {
            $cpasswordErr = "Password and Confirm Password don't match";
            $isValid = false;
        }
    }

    
    if ($isValid) {
       
        $insert = "INSERT INTO php.USER (fname, email, password, cpassword) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insert);
        $stmt->bind_param("ssss", $fname, $email, $password, $cpassword);
        $fname = $_POST['fname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];
        
        /*if ($stmt->execute()) {
            $_SESSION['email'] = $email;
            $_SESSION['fname'] = $fname;  
            echo "New record created successfully";
            header("Location: login.php");
            exit(); 
            
        } else {
            echo "Error: " . $stmt->error;
        }*/
        if ($stmt->execute()) {
           
            setcookie('email', $email, time() + 60, '/');
            setcookie('fname', $fname, time() + 60, '/');
            
            echo "New record created successfully";
            header("Location: login.php");
            exit(); 
        } else {
            echo "Error: " . $stmt->error;
        }
        
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
        body
        {
            background-color: lightblue;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center">PHP Signup Form</h2>
    <p><span class="error">* required field</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
        <div class="form-group">
            <label for="fname">Name:</label>
            <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $name; ?>">
            <span class="error">* <?php echo $nameErr;?></span>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
            <span class="error">* <?php echo $emailErr;?></span>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password">
            <span class="error">* <?php echo $passwordErr;?></span>
        </div>
        <div class="form-group">
            <label for="cpassword">Confirm Password:</label>
            <input type="password" class="form-control" id="cpassword" name="cpassword">
            <span class="error">* <?php echo $cpasswordErr;?></span>
        </div>
        
        <button  type="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>

    <?php
    if ($isValid) {
        /*echo "<h2 class='mt-4'>Your Input:</h2>";
        echo "<p><strong>Name:</strong> " . $name . "</p>";
        echo "<p><strong>Email:</strong> " . $email . "</p>";*/
    }
    ?>

</div>


</body>
</html>

<?php

$conn->close();
?>
