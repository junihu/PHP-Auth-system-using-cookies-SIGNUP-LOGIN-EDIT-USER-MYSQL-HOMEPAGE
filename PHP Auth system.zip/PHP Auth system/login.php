<?php
include 'config.php';

$email = $password = "";
$emailErr = $passwordErr = "";
$isValid = true;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['email'])) {
        $emailErr = "Email is Required";
        $isValid = false;
    } else {
        $email = $_POST['email'];
    }

    if (empty($_POST['password'])) {
        $passwordErr = "Password is required";
        $isValid = false;
    } else {
        $password = $_POST['password'];
    }

    if ($isValid) {
        $sql = "SELECT * FROM php.USER WHERE email=? AND password=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Successful login
            $row = $result->fetch_assoc();

            
            setcookie('loggedin', 'true', time() + 60, '/'); // Cookie valid for 1 hour
            setcookie('email', $email, time() + 60, '/');
            
            // Redirect to home.php or other desired page
            header("Location: home.php");
            exit();
        } else {
            // Invalid credentials
            echo "Invalid email or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
        body {
            background-color: lightblue;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center">PHP Login Form</h2>
        <p><span class="error">* required field</span></p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
                <span class="error">* <?php echo $emailErr;?></span>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password">
                <span class="error">* <?php echo $passwordErr;?></span>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Login</button>
            <a href="index.php" class="ml-2">Sign up?</a>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
