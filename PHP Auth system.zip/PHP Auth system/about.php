<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
    <?php
        $myfile = fopen("testfile.txt", "a")or die("unable to open the file");
        $txt="This is my about page and the data is being fetched from .txt file";
        fwrite($myfile,$txt);
        echo $txt;
        $txt2="This is the appended text";
        fwrite($myfile,$txt2);
        fclose($myfile);
    ?>
</body>
</html>