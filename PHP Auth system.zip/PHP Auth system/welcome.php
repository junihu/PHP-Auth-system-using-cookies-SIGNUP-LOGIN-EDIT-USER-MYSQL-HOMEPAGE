<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
 welcome:<?php
    echo $_POST['fname'];
    echo "<br>";
 ?>
 Your Email Address is:<?php
    echo $_POST['email'];
    echo "<br>";
 ?>
 your Password is:<?php
    echo $_POST['password'];
    echo "<br>";
 ?>    
</body>
</html>